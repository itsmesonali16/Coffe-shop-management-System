create table feed(
name varchar( 20),
occupation varchar(12),
gender varchar(2));
